<?php
session_start();
require_once '../includes/conexion.php'; // Asegúrate de que $pdo está definido aquí

$usuario = trim($_POST['usuario'] ?? '');
$clave = trim($_POST['clave'] ?? '');

if ($usuario === '' || $clave === '') {
    echo "<script>alert('Por favor, complete todos los campos'); window.location='../login.php';</script>";
    exit();
}

try {
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE usuario = :usuario AND estado = 'activo'");
    $stmt->execute(['usuario' => $usuario]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row && $clave === $row['clave']) {
        // Inicio de sesión exitoso
        $_SESSION['usuario'] = $row['usuario'];
        $_SESSION['rol'] = $row['rol'];

        if ($row['rol'] === 'admin') {
            header("Location: ../dashboard.php");
            exit();
        } else {
            echo "<script>alert('Acceso restringido: solo administradores'); window.location='../login.php';</script>";
            exit();
        }
    } else {
        echo "<script>alert('Credenciales incorrectas o usuario inactivo'); window.location='../login.php';</script>";
        exit();
    }
} catch (PDOException $e) {
    echo "<script>alert('Error de conexión: " . $e->getMessage() . "'); window.location='../login.php';</script>";
}
