<?php
$host = "localhost";
$dbname = "bd";
$user = "root";
$pass = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Habilita excepciones
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC); // Opcional: fetch más limpio
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}
?>
