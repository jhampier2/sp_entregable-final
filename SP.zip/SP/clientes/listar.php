<?php include '../includes/sesion.php'; ?>
<?php
include 'conexion.php';

$stmt = $pdo->query("CALL sp_listar_clientes()");
$clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
$stmt->closeCursor(); // <- Esta línea es CLAVE cuando usas procedimientos almacenados

echo json_encode($clientes);
?>
