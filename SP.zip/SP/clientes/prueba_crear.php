<?php
include 'conexion.php';

try {
    $stmt = $pdo->prepare("CALL sp_insertar_clientes(?, ?, ?, ?)");
    $stmt->execute(["PruebaNombre", "PruebaApellido", "Direccion X", "999999999"]);
    echo "Cliente creado exitosamente.";
} catch (PDOException $e) {
    echo "Error al insertar: " . $e->getMessage();
}
