<?php include '../includes/sesion.php'; ?>
<?php
include 'conexion.php';

try {
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $direccion = $_POST['direccion'];
    $telefono = $_POST['telefono'];

    $stmt = $pdo->prepare("CALL sp_insertar_clientes(?, ?, ?, ?)");
    $stmt->execute([$nombres, $apellidos, $direccion, $telefono]);

    echo "Cliente creado correctamente.";
} catch (PDOException $e) {
    echo "Error al crear cliente: " . $e->getMessage();
}
?>
