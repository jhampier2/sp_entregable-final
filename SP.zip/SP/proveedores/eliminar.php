<?php
include 'conexion.php';
header('Content-Type: application/json');

$id = $_POST['id_proveedor'] ?? '';

if (empty($id) || !is_numeric($id)) {
    echo json_encode(['error' => 'ID de proveedor inválido']);
    exit;
}

try {
    $stmt = $pdo->prepare("CALL sp_eliminar_proveedor(:id)");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();

    echo json_encode(['success' => 'Proveedor eliminado correctamente']);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Error al eliminar proveedor: ' . $e->getMessage()]);
}
?>
