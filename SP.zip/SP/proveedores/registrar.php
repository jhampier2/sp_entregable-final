<?php
include 'conexion.php';

$razonsocial = $_POST['razonsocial'] ?? '';
$direccion = $_POST['direccion'] ?? '';
$telefono = $_POST['telefono'] ?? '';

if (empty($razonsocial)) {
    http_response_code(400);
    echo 'La razón social es obligatoria';
    exit;
}

try {
    $stmt = $pdo->prepare("CALL sp_insertar_proveedor(:razonsocial, :direccion, :telefono)");
    $stmt->bindParam(':razonsocial', $razonsocial);
    $stmt->bindParam(':direccion', $direccion);
    $stmt->bindParam(':telefono', $telefono);
    $stmt->execute();
    echo 'Proveedor registrado con éxito';
} catch (PDOException $e) {
    http_response_code(500);
    echo 'Error al registrar proveedor: ' . $e->getMessage();
}
?>
