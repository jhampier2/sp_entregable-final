<?php
include 'conexion.php';
header('Content-Type: application/json');

$id = $_POST['id_proveedor'] ?? '';
$razonsocial = $_POST['razonsocial'] ?? '';
$direccion = $_POST['direccion'] ?? '';
$telefono = $_POST['telefono'] ?? '';

try {
    $stmt = $pdo->prepare("CALL sp_actualizar_proveedor(:id, :razonsocial, :direccion, :telefono)");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':razonsocial', $razonsocial);
    $stmt->bindParam(':direccion', $direccion);
    $stmt->bindParam(':telefono', $telefono);
    $stmt->execute();

    echo json_encode(['success' => 'Proveedor actualizado correctamente']);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
