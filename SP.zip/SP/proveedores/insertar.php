<?php
include 'conexion.php';
header('Content-Type: application/json');

$razonsocial = $_POST['razonsocial'] ?? '';
$direccion = $_POST['direccion'] ?? '';
$telefono = $_POST['telefono'] ?? '';

try {
    $stmt = $pdo->prepare("CALL sp_insertar_proveedor(:razonsocial, :direccion, :telefono)");
    $stmt->bindParam(':razonsocial', $razonsocial);
    $stmt->bindParam(':direccion', $direccion);
    $stmt->bindParam(':telefono', $telefono);
    $stmt->execute();

    echo json_encode(['success' => 'Proveedor insertado correctamente']);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
