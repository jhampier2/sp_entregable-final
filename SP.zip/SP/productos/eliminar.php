<?php
include 'conexion.php';

$id_producto = $_GET['id_producto'] ?? '';

if (empty($id_producto)) {
    http_response_code(400);
    echo 'ID requerido';
    exit;
}

$stmt = $pdo->prepare("CALL sp_eliminar_producto(:id_producto)");
$stmt->bindParam(':id_producto', $id_producto, PDO::PARAM_INT);

if ($stmt->execute()) {
    echo 'Producto eliminado con éxito';
} else {
    http_response_code(500);
    echo 'Error al eliminar producto';
}
