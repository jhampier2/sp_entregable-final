<?php
include 'conexion.php';

$id_producto = $_POST['id_producto'] ?? '';
$nombre = $_POST['nombre'] ?? '';
$descripcion = $_POST['descripcion'] ?? '';
$precio = $_POST['precio'] ?? '';
$stock = $_POST['stock'] ?? '';
$id_categoria = $_POST['id_categoria'] ?? '';
$id_proveedor = $_POST['id_proveedor'] ?? '';

if (
    !is_numeric($id_producto) || empty($nombre) || empty($descripcion) ||
    !is_numeric($precio) || !is_numeric($stock) || 
    !is_numeric($id_categoria) || !is_numeric($id_proveedor)
) {
    http_response_code(400);
    echo 'Datos incompletos o inválidos';
    exit;
}

$stmt = $pdo->prepare("CALL sp_actualizar_producto(:id_producto, :nombre, :descripcion, :precio, :stock, :id_categoria, :id_proveedor)");
$stmt->bindParam(':id_producto', $id_producto, PDO::PARAM_INT);
$stmt->bindParam(':nombre', $nombre);
$stmt->bindParam(':descripcion', $descripcion);
$stmt->bindParam(':precio', $precio);
$stmt->bindParam(':stock', $stock, PDO::PARAM_INT);
$stmt->bindParam(':id_categoria', $id_categoria, PDO::PARAM_INT);
$stmt->bindParam(':id_proveedor', $id_proveedor, PDO::PARAM_INT);

if ($stmt->execute()) {
    echo 'Producto actualizado con éxito';
} else {
    http_response_code(500);
    echo 'Error al actualizar producto';
}
