<?php
header('Content-Type: application/json');

try {
    require_once 'conexion.php'; // Asegúrate de que esta ruta sea correcta

    $stmt = $pdo->prepare("CALL sp_listar_productos()");
    $stmt->execute();
    $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($productos);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Error al listar productos: ' . $e->getMessage()]);
}
