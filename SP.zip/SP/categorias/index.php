<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>CRUD de Categorías</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
      body {
        background: url("../img/inicio.jpg") no-repeat center center fixed;
        background-size: cover;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: #333;
        margin: 20px;
        padding: 0;
      }

      section {
        background: rgba(255, 255, 255, 0.92); /* Fondo blanco translúcido para mejor lectura */
        padding: 20px 30px;
        border-radius: 10px;
        box-shadow: 0 3px 8px rgba(0,0,0,0.1);
        max-width: 600px;
        margin: 0 auto 40px;
      }
    </style>

</head>
<body>
  <div class="container my-4">
    <h2>Administración de Categorías</h2>
    <p><a href="../dashboard.php">⬅ Volver al Panel Principal</a></p>

    <!-- Alertas -->
    <div id="alerta" role="alert"></div>

    <!-- Formulario para crear nueva categoría -->
    <form id="formCrear" class="mb-4 d-flex gap-2">
      <input
        type="text"
        id="descripcion_crear"
        class="form-control"
        placeholder="Descripción de la categoría"
        required
      />
      <button type="submit" class="btn btn-success">Agregar</button>
    </form>

    <!-- Lista de categorías -->
    <div id="listaCategorias" class="list-group mb-4"></div>

    <!-- Modal Editar -->
    <div class="modal fade" id="modalEditar" tabindex="-1" aria-labelledby="modalEditarLabel" aria-hidden="true">
      <div class="modal-dialog">
        <form id="formEditar" class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalEditarLabel">Editar Categoría</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" id="id_categoria_edit" />
            <div class="mb-3">
              <label for="descripcion_edit" class="form-label">Descripción</label>
              <input type="text" id="descripcion_edit" class="form-control" required />
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary">Guardar cambios</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Modal Eliminar -->
    <div class="modal fade" id="modalEliminar" tabindex="-1" aria-labelledby="modalEliminarLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalEliminarLabel">Confirmar eliminación</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
          </div>
          <div class="modal-body">
            <p>¿Está seguro que desea eliminar esta categoría?</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="button" id="btnConfirmarEliminar" class="btn btn-danger">Eliminar</button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS + Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  <script>
    // Variables globales para modal
    const alerta = document.getElementById('alerta');
    const listaCategorias = document.getElementById('listaCategorias');

    // Instancias de modales Bootstrap
    const modalEditar = new bootstrap.Modal(document.getElementById('modalEditar'));
    const modalEliminar = new bootstrap.Modal(document.getElementById('modalEliminar'));

    // ID para eliminar (se asigna al abrir el modal)
    let idAEliminar = null;

    // Mostrar alerta (texto + color)
    function mostrarAlerta(msg, tipo = 'success') {
      alerta.textContent = msg;
      alerta.className = ''; // limpiar clases
      alerta.classList.add('alert', tipo === 'success' ? 'alert-success' : 'alert-danger');
      setTimeout(() => {
        alerta.textContent = '';
        alerta.className = '';
      }, 4000);
    }

    // Escapar comillas para usar en onclick (string JS)
    function escaparComillas(texto) {
      if (!texto) return '';
      return texto.replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/"/g, '\\"');
    }

    // Cargar categorías desde listar.php
    async function cargarCategorias() {
      try {
        const res = await fetch('listar.php');
        if (!res.ok) throw new Error('Error al cargar categorías');
        const categorias = await res.json();

        listaCategorias.innerHTML = '';

        if (!Array.isArray(categorias) || categorias.length === 0) {
          listaCategorias.innerHTML = '<p class="text-muted">No hay categorías registradas.</p>';
          return;
        }

        categorias.forEach(cat => {
          const nombreEscapado = escaparComillas(cat.descripcion);
          const item = document.createElement('div');
          item.className = 'list-group-item d-flex justify-content-between align-items-center';
          item.innerHTML = `
            <div>${cat.descripcion}</div>
            <div>
              <button class="btn btn-sm btn-outline-warning me-2" onclick="abrirEditar(${cat.id_categoria}, '${nombreEscapado}')">Editar</button>
              <button class="btn btn-sm btn-outline-danger" onclick="abrirEliminar(${cat.id_categoria})">Eliminar</button>
            </div>
          `;
          listaCategorias.appendChild(item);
        });
      } catch (error) {
        mostrarAlerta(error.message, 'error');
      }
    }

    // Abrir modal para editar con datos
    function abrirEditar(id, descripcion) {
      document.getElementById('id_categoria_edit').value = id;
      document.getElementById('descripcion_edit').value = descripcion;
      modalEditar.show();
    }

    // Abrir modal para eliminar
    function abrirEliminar(id) {
      idAEliminar = id;
      modalEliminar.show();
    }

    // Manejar formulario editar
    document.getElementById('formEditar').addEventListener('submit', async (e) => {
      e.preventDefault();
      const id = document.getElementById('id_categoria_edit').value.trim();
      const descripcion = document.getElementById('descripcion_edit').value.trim();

      if (!descripcion) {
        mostrarAlerta('La descripción no puede estar vacía', 'error');
        return;
      }

      const formData = new FormData();
      formData.append('id_categoria', id);
      formData.append('descripcion', descripcion);

      try {
        const res = await fetch('editar.php', {
          method: 'POST',
          body: formData
        });
        const respuesta = await res.text();

        if (respuesta.includes('"error"')) {
          const error = JSON.parse(respuesta).error;
          throw new Error(error);
        }

        mostrarAlerta(respuesta);
        modalEditar.hide();
        cargarCategorias();
      } catch (err) {
        mostrarAlerta(err.message || 'Error al editar', 'error');
      }
    });

    // Confirmar eliminar botón
    document.getElementById('btnConfirmarEliminar').addEventListener('click', async () => {
      if (!idAEliminar) return;

      try {
        const res = await fetch(`eliminar.php?id_categoria=${idAEliminar}`);
        const respuesta = await res.text();

        if (respuesta.includes('"error"')) {
          const error = JSON.parse(respuesta).error;
          throw new Error(error);
        }

        mostrarAlerta(respuesta);
        modalEliminar.hide();
        cargarCategorias();
      } catch (err) {
        mostrarAlerta(err.message || 'Error al eliminar', 'error');
      }
    });

    // Manejar formulario crear nueva categoría
    document.getElementById('formCrear').addEventListener('submit', async (e) => {
      e.preventDefault();
      const descripcion = document.getElementById('descripcion_crear').value.trim();

      if (!descripcion) {
        mostrarAlerta('La descripción no puede estar vacía', 'error');
        return;
      }

      const formData = new FormData();
      formData.append('descripcion', descripcion);

      try {
        const res = await fetch('registrar.php', {
          method: 'POST',
          body: formData
        });
        const respuesta = await res.text();

        if (respuesta.includes('"error"')) {
          const error = JSON.parse(respuesta).error;
          throw new Error(error);
        }

        mostrarAlerta(respuesta);
        document.getElementById('formCrear').reset();
        cargarCategorias();
      } catch (err) {
        mostrarAlerta(err.message || 'Error al agregar categoría', 'error');
      }
    });

    // Cargar categorías al iniciar
    cargarCategorias();
  </script>
</body>
</html>
