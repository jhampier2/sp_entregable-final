<?php
header('Content-Type: application/json; charset=utf-8');
include '../includes/conexion.php';

$id = intval($_POST['id_categoria'] ?? 0);
$descripcion = trim($_POST['descripcion'] ?? '');

try {
    $stmt = $pdo->prepare("CALL sp_editar_categoria(:id, :descripcion)");
    $stmt->bindParam(':id', $id);
    $stmt->bindParam(':descripcion', $descripcion);
    $stmt->execute();
    echo "Categoría actualizada correctamente";
} catch (PDOException $e) {
    echo json_encode(['error' => "Error: " . $e->getMessage()]);
}
?>
