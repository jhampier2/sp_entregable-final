<?php
header('Content-Type: application/json; charset=utf-8');
include '../includes/conexion.php';

$id = intval($_GET['id_categoria'] ?? 0);

try {
    $stmt = $pdo->prepare("CALL sp_eliminar_categoria(:id)");
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    echo "Categoría eliminada correctamente";
} catch (PDOException $e) {
    echo json_encode(['error' => "Error: " . $e->getMessage()]);
}
?>
