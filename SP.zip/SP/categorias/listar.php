<?php
header('Content-Type: application/json; charset=utf-8');
include '../includes/conexion.php';

try {
    $stmt = $pdo->query("CALL sp_listar_categorias()");
    $categorias = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($categorias);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
