<?php
header('Content-Type: application/json; charset=utf-8');
include '../includes/conexion.php';

$descripcion = trim($_POST['descripcion'] ?? '');

try {
    $stmt = $pdo->prepare("CALL sp_registrar_categoria(:descripcion)");
    $stmt->bindParam(':descripcion', $descripcion);
    $stmt->execute();
    echo "Categoría registrada correctamente";
} catch (PDOException $e) {
    echo json_encode(['error' => "Error: " . $e->getMessage()]);
}
?>
