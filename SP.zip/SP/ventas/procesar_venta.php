<?php
include 'conexion.php';

$fecha = $_POST['fecha'] ?? null;
$id_cliente = $_POST['id_cliente'] ?? null;
$productos = $_POST['productos'] ?? [];
$cantidades = $_POST['cantidades'] ?? [];

if (!$fecha || !$id_cliente || empty($productos)) {
    die("Faltan datos");
}

try {
    $pdo->beginTransaction();

    // Ejecutar sp_insertar_venta
    $stmtVenta = $pdo->prepare("CALL sp_insertar_venta(:fecha, :id_cliente, @id_venta)");
    $stmtVenta->bindParam(':fecha', $fecha);
    $stmtVenta->bindParam(':id_cliente', $id_cliente, PDO::PARAM_INT);
    $stmtVenta->execute();
    $stmtVenta->closeCursor();

    // Obtener el id_venta generado
    $stmtId = $pdo->query("SELECT @id_venta AS id_venta");
    $id_venta = $stmtId->fetch(PDO::FETCH_ASSOC)['id_venta'];

    // Insertar cada detalle con el SP
    $stmtDetalle = $pdo->prepare("CALL sp_insertar_detalle_venta(:id_venta, :id_producto, :cantidad)");

    for ($i = 0; $i < count($productos); $i++) {
        $stmtDetalle->bindParam(':id_venta', $id_venta, PDO::PARAM_INT);
        $stmtDetalle->bindParam(':id_producto', $productos[$i], PDO::PARAM_INT);
        $stmtDetalle->bindParam(':cantidad', $cantidades[$i], PDO::PARAM_INT);
        $stmtDetalle->execute();
        $stmtDetalle->closeCursor();
    }

    $pdo->commit();
    header("Location: index.php?msg=venta_exitosa");

} catch (PDOException $e) {
    $pdo->rollBack();
    die("Error: " . $e->getMessage());
}
?>
