<?php
include 'conexion.php';

header('Content-Type: application/json'); // indicar que será JSON

$id_venta = $_GET['id_venta'] ?? null;

if (!$id_venta) {
    echo json_encode(['error' => 'ID de venta requerido']);
    exit;
}

try {
    $stmt = $pdo->prepare("CALL sp_eliminar_venta(:id_venta)");
    $stmt->bindParam(':id_venta', $id_venta, PDO::PARAM_INT);
    $stmt->execute();
    $stmt->closeCursor();

    echo json_encode(['success' => 'Venta eliminada correctamente']);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
