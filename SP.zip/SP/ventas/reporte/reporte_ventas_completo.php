<?php
require('../fpdf186/fpdf.php');
require('conexion.php');

class PDF extends FPDF {
    protected $widths;
    protected $lineHeight;

    function __construct($orientation='L', $unit='mm', $size='A4') {
        parent::__construct($orientation, $unit, $size);
        // Definir anchos columnas y altura linea base
        $this->widths = [15, 30, 30, 40, 70, 20];
        $this->lineHeight = 7;
    }

    // Método público para obtener la suma de anchos de columnas desde índice start con cantidad length
    public function getSumWidths($start, $length) {
        return array_sum(array_slice($this->widths, $start, $length));
    }

    // Calcular número de líneas que ocupará un texto en MultiCell
    function NbLines($w, $txt) {
        $cw = &$this->CurrentFont['cw'];
        if ($w == 0) $w = $this->w - $this->rMargin - $this->x;
        $wmax = ($w - 2 * $this->cMargin) * 1000 / $this->FontSize;
        $s = str_replace("\r", '', $txt);
        $nb = strlen($s);
        if ($nb > 0 && $s[$nb-1] == "\n") $nb--;

        $sep = -1; $i = 0; $j = 0; $l = 0; $nl = 1;

        while ($i < $nb) {
            $c = $s[$i];
            if ($c == "\n") {
                $i++; $sep = -1; $j = $i; $l = 0; $nl++;
                continue;
            }
            if ($c == ' ') $sep = $i;
            if (isset($cw[$c])) {
                $l += $cw[$c];
            } else {
                // Caracter desconocido, contar como ancho medio letra
                $l += $cw['0']; 
            }
            if ($l > $wmax) {
                if ($sep == -1) {
                    if ($i == $j) $i++;
                } else {
                    $i = $sep + 1;
                }
                $sep = -1; $j = $i; $l = 0; $nl++;
            } else {
                $i++;
            }
        }
        return $nl;
    }

    // Cabecera: logo + título + fecha + línea divisoria
    function Header() {
        // Logo a la izquierda
        $this->Image('../../img/senati.png', 10, 6, 30);
        // Fuente titulo
        $this->SetFont('Helvetica', 'B', 18);
        $this->SetTextColor(0,51,102); // Color azul oscuro corporativo
        // Título centrado + con margen izquierda y derecha
        $this->Cell(0, 10, 'Reporte Completo de Ventas', 0, 1, 'C');

        // Fecha actual de impresión, alineación derecha en misma línea del título, altura relativa
        $this->SetY(15);
        $this->SetFont('Helvetica', '', 10);
        $this->SetTextColor(80);
        $this->Cell(0, 10, 'Fecha: ' . date('d/m/Y H:i'), 0, 1, 'R');
        $this->Ln(2);

        // Encabezado tabla fondo azul claro
        $this->SetFont('Helvetica', 'B', 12);
        $this->SetFillColor(200, 220, 255);
        $this->SetDrawColor(50, 50, 100);
        $headers = ['ID Venta', 'Fecha', 'Cliente', 'Producto', 'Descripción', 'Cantidad'];

        foreach ($headers as $i => $header) {
            $this->Cell($this->widths[$i], 10, $header, 1, 0, 'C', true);
        }
        $this->Ln();
    }

    // Pie de página con paginación
    function Footer() {
        $this->SetY(-15);
        $this->SetDrawColor(150);
        $this->Line($this->lMargin, $this->GetY(), $this->w - $this->rMargin, $this->GetY());
        $this->SetFont('Helvetica', 'I', 9);
        $this->SetTextColor(100);
        $this->Cell(0, 10, 'Página ' . $this->PageNo() . ' de {nb}', 0, 0, 'C');
    }

    // Función para imprimir una fila con datos, altura ajustada y alternar color fila (striped)
    function Row($data, $fill) {
        $nbLines = [];
        // Calcular altura basada en cantidad de líneas por columna
        foreach ($data as $i => $txt) {
            $nbLines[$i] = $this->NbLines($this->widths[$i], $txt);
        }
        $maxLines = max($nbLines);
        $h = $this->lineHeight * $maxLines;

        // Verificar si queda espacio para la fila, si no, agregar nueva página
        if ($this->GetY() + $h > $this->PageBreakTrigger) {
            $this->AddPage();
        }

        // Establece colores para filas alternas
        if ($fill) {
            $this->SetFillColor(240, 248, 255); // azul muy claro tipo AliceBlue
            $this->SetTextColor(0, 0, 0);
        } else {
            $this->SetFillColor(255, 255, 255);
            $this->SetTextColor(0, 0, 0);
        }

        $x = $this->GetX();
        $y = $this->GetY();

        // ID Venta y Fecha (texto simple)
        $this->Rect($x, $y, $this->widths[0], $h, 'DF');
        $this->Cell($this->widths[0], $h, $data[0], 0, 0, 'C');

        $this->SetXY($x + $this->widths[0], $y);
        $this->Rect($x + $this->widths[0], $y, $this->widths[1], $h, 'DF');
        $this->Cell($this->widths[1], $h, $data[1], 0, 0, 'C');

        // Cliente
        $this->SetXY($x + $this->widths[0] + $this->widths[1], $y);
        $this->Rect($x + $this->widths[0] + $this->widths[1], $y, $this->widths[2], $h, 'DF');
        $this->MultiCell($this->widths[2], $this->lineHeight, $data[2], 0, 'L', true);

        // Producto
        $this->SetXY($x + $this->widths[0] + $this->widths[1] + $this->widths[2], $y);
        $this->Rect($x + $this->widths[0] + $this->widths[1] + $this->widths[2], $y, $this->widths[3], $h, 'DF');
        $this->MultiCell($this->widths[3], $this->lineHeight, $data[3], 0, 'L', true);

        // Descripción
        $this->SetXY($x + $this->widths[0] + $this->widths[1] + $this->widths[2] + $this->widths[3], $y);
        $this->Rect($x + $this->widths[0] + $this->widths[1] + $this->widths[2] + $this->widths[3], $y, $this->widths[4], $h, 'DF');
        $this->MultiCell($this->widths[4], $this->lineHeight, $data[4], 0, 'J', true);

        // Cantidad
        $this->SetXY($x + array_sum(array_slice($this->widths, 0, 5)), $y);
        $this->Rect($x + array_sum(array_slice($this->widths, 0, 5)), $y, $this->widths[5], $h, 'DF');
        $this->Cell($this->widths[5], $h, $data[5], 0, 0, 'C');

        $this->Ln($h);
    }
}

// Configuración de zona horaria
date_default_timezone_set('America/Lima'); // Ajusta según tu zona horaria

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Helvetica', '', 11);

try {
    $sql = "SELECT v.id_venta, v.fecha, 
            CONCAT(c.nombres, ' ', c.apellidos) as cliente,
            p.nombre as producto,
            p.descripcion,
            dv.cantidad
            FROM ventas v
            INNER JOIN clientes c ON v.id_cliente = c.id_cliente
            INNER JOIN detalle_ventas dv ON v.id_venta = dv.id_venta
            INNER JOIN productos p ON dv.id_producto = p.id_producto
            ORDER BY v.id_venta";

    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $ventas = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error en la consulta: " . $e->getMessage());
}

$totalCantidad = 0;
$fill = false;

foreach ($ventas as $row) {
    $fecha = date('d/m/Y', strtotime($row['fecha']));
    $totalCantidad += $row['cantidad'];

    $data = [
        $row['id_venta'],
        $fecha,
        $row['cliente'],
        $row['producto'],
        $row['descripcion'],
        $row['cantidad']
    ];

    $pdf->Row($data, $fill);
    $fill = !$fill;
}

// Fila total general con acceso mediante método público para anchos
$pdf->SetFont('Helvetica', 'B', 12);
$pdf->SetFillColor(200, 220, 255);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell($pdf->getSumWidths(0, 5), 10, 'Total Cantidad', 1, 0, 'R', true);
$pdf->Cell($pdf->getSumWidths(5, 1), 10, $totalCantidad, 1, 1, 'C', true);

$pdf->Output('D', 'reporte_ventas_completo.pdf');
?>

