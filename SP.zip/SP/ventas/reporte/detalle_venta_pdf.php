<?php
include '../fpdf186/fpdf.php';
include 'conexion.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) { die("ID inválido"); }

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, "Detalle de Venta ID $id", 0, 1, 'C');

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(80, 10, 'Producto', 1);
$pdf->Cell(30, 10, 'Cantidad', 1);
$pdf->Cell(30, 10, 'Precio', 1);
$pdf->Cell(50, 10, 'Subtotal', 1);
$pdf->Ln();

$stmt = $pdo->prepare("CALL sp_detalle_venta(?)");
$stmt->execute([$id]);
$detalles = $stmt->fetchAll(PDO::FETCH_ASSOC);
$stmt->closeCursor();

$pdf->SetFont('Arial', '', 11);
$total = 0;
foreach ($detalles as $d) {
    $pdf->Cell(80, 10, utf8_decode($d['producto']), 1);
    $pdf->Cell(30, 10, $d['cantidad'], 1);
    $pdf->Cell(30, 10, number_format($d['precio'], 2), 1);
    $pdf->Cell(50, 10, number_format($d['subtotal'], 2), 1);
    $pdf->Ln();
    $total += $d['subtotal'];
}

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(140, 10, 'TOTAL', 1);
$pdf->Cell(50, 10, number_format($total, 2), 1);

$pdf->Output();
