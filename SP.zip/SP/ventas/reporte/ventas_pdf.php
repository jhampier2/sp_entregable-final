<?php
include '../fpdf186/fpdf.php';
include 'conexion.php';

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Reporte de Ventas', 0, 1, 'C');

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(30, 10, 'ID', 1);
$pdf->Cell(60, 10, 'Fecha', 1);
$pdf->Cell(100, 10, 'Cliente', 1);
$pdf->Ln();

$stmt = $pdo->query("CALL sp_reporte_ventas()");
$ventas = $stmt->fetchAll(PDO::FETCH_ASSOC);
$stmt->closeCursor();

$pdf->SetFont('Arial', '', 11);
foreach ($ventas as $venta) {
    $pdf->Cell(30, 10, $venta['id_venta'], 1);
    $pdf->Cell(60, 10, $venta['fecha'], 1);
    $pdf->Cell(100, 10, utf8_decode($venta['cliente']), 1);
    $pdf->Ln();
}

$pdf->Output();
