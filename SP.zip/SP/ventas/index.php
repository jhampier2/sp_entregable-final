<?php
include 'conexion.php';

try {
    $stmt = $pdo->query("CALL sp_listar_ventas()");
    $ventas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
} catch (PDOException $e) {
    die("Error al listar ventas: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ventas | Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
      background: url('../img/inicio.jpg') no-repeat center center fixed;
      background-size: cover;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 2rem 1rem;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: #fff;
      position: relative;
    }
    </style>
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary">Ventas Registradas</h2>
        <div>
            <a href="registrar.php" class="btn btn-success me-2">➕ Nueva Venta</a>
            <a href="../dashboard.php" class="btn btn-secondary">⬅ Volver al Panel</a>
        </div>
    </div>

    <?php if (count($ventas) > 0): ?>
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle" id="tablaVentas">
                <thead class="table-dark">
                    <tr>
                        <th>ID Venta</th>
                        <th>Fecha</th>
                        <th>Cliente</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($ventas as $venta): ?>
                        <tr data-id="<?= htmlspecialchars($venta['id_venta']) ?>">
                            <td><?= htmlspecialchars($venta['id_venta']) ?></td>
                            <td><?= date('d/m/Y H:i', strtotime($venta['fecha'])) ?></td>
                            <td><?= htmlspecialchars($venta['nombre_cliente']) ?></td>
                            <td>
                                <a href="editar.php?id=<?= urlencode($venta['id_venta']) ?>" class="btn btn-sm btn-primary">✏️ Editar</a>
                                <a href="#" class="btn btn-sm btn-danger btn-eliminar" data-id="<?= $venta['id_venta'] ?>">🗑️ Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-info text-center">
            No se han registrado ventas aún.
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Eliminar venta con confirmación y AJAX
document.querySelectorAll('.btn-eliminar').forEach(button => {
  button.addEventListener('click', function(e) {
    e.preventDefault();
    if (!confirm('¿Desea eliminar esta venta?')) return;

    const id_venta = this.dataset.id;

    fetch(`eliminar.php?id_venta=${id_venta}`)
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          alert(data.success);
          // Eliminar la fila de la tabla
          const fila = this.closest('tr');
          fila.parentNode.removeChild(fila);
        } else if (data.error) {
          alert('Error: ' + data.error);
        }
      })
      .catch(() => alert('Error al comunicarse con el servidor'));
  });
});
</script>

</body>
</html>
