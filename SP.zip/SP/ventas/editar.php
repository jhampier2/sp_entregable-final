<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Actualizar venta
    $id_venta = $_POST['id_venta'] ?? null;
    $fecha = $_POST['fecha'] ?? null;
    $id_cliente = $_POST['id_cliente'] ?? null;

    if (!$id_venta || !$fecha || !$id_cliente) {
        echo json_encode(['error' => 'Todos los campos son obligatorios']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("CALL sp_editar_venta(:id_venta, :fecha, :id_cliente)");
        $stmt->bindParam(':id_venta', $id_venta, PDO::PARAM_INT);
        $stmt->bindParam(':fecha', $fecha);
        $stmt->bindParam(':id_cliente', $id_cliente, PDO::PARAM_INT);
        $stmt->execute();
        $stmt->closeCursor();

        echo json_encode(['success' => 'Venta editada correctamente']);
        exit;

    } catch (PDOException $e) {
        echo json_encode(['error' => $e->getMessage()]);
        exit;
    }
}

// GET para mostrar formulario con datos actuales
$id_venta = $_GET['id'] ?? null;
if (!$id_venta) {
    die("ID de venta no especificado");
}

try {
    $stmt = $pdo->prepare("CALL sp_obtener_venta(:id_venta)");
    $stmt->bindParam(':id_venta', $id_venta, PDO::PARAM_INT);
    $stmt->execute();
    $venta = $stmt->fetch(PDO::FETCH_ASSOC);
    $stmt->closeCursor();

    if (!$venta) {
        die("Venta no encontrada");
    }

    // Obtener clientes para el select
    $stmtClientes = $pdo->query("CALL sp_listar_clientes()");
    $clientes = $stmtClientes->fetchAll(PDO::FETCH_ASSOC);
    $stmtClientes->closeCursor();

} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!-- Formulario HTML aquí -->
<form method="post" action="editar.php">
    <input type="hidden" name="id_venta" value="<?= htmlspecialchars($venta['id_venta']) ?>">
    <label>Fecha:</label>
    <input type="datetime-local" name="fecha" value="<?= date('Y-m-d\TH:i', strtotime($venta['fecha'])) ?>" required>
    <label>Cliente:</label>
    <select name="id_cliente" required>
        <?php foreach ($clientes as $cliente): ?>
            <option value="<?= htmlspecialchars($cliente['id_cliente']) ?>" <?= $cliente['id_cliente'] == $venta['id_cliente'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($venta['nombre_cliente']) ?>

            </option>
        <?php endforeach; ?>
    </select>
    <button type="submit">Guardar</button>
</form>
