<?php
include 'conexion.php';

// Obtener clientes
$stmtClientes = $pdo->query("CALL sp_listar_clientes()");
$clientes = $stmtClientes->fetchAll(PDO::FETCH_ASSOC);
$stmtClientes->closeCursor();

// Obtener productos
$stmtProductos = $pdo->query("CALL sp_listar_productos()");
$productos = $stmtProductos->fetchAll(PDO::FETCH_ASSOC);
$stmtProductos->closeCursor();
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Registrar Venta</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: url('../img/inicio.jpg') no-repeat center center fixed;
      background-size: cover;
      min-height: 100vh;
      padding: 2rem 1rem;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: #fff;
    }
    .bg-glass {
      background: rgba(255, 255, 255, 0.15);
      border-radius: 1rem;
      padding: 2rem;
      box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
      backdrop-filter: blur(5px);
      color: #fff;
    }
  </style>
</head>
<body>
<div class="container bg-glass mt-5">
  <h2 class="text-warning mb-4">Registrar Nueva Venta</h2>

  <form method="POST" action="procesar_registro.php">
    <div class="mb-3">
      <label for="id_cliente" class="form-label">Cliente:</label>
      <select name="id_cliente" id="id_cliente" class="form-select" required>
        <option value="">Seleccione un cliente</option>
        <?php foreach ($clientes as $cliente): ?>
          <option value="<?= $cliente['id_cliente'] ?>">
            <?= htmlspecialchars($cliente['nombres'] . ' ' . $cliente['apellidos']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="mb-3">
      <label for="fecha" class="form-label">Fecha:</label>
      <input type="datetime-local" name="fecha" id="fecha" class="form-control" required>
    </div>

    <h5 class="mt-4 text-info">Productos:</h5>
    <div id="productos-container">
      <div class="row mb-3 producto-item">
        <div class="col-md-4">
          <select name="productos[]" class="form-select producto-select" required>
            <option value="">Seleccione producto</option>
            <?php foreach ($productos as $producto): ?>
              <option value="<?= $producto['id_producto'] ?>"
                      data-nombre="<?= htmlspecialchars($producto['nombre']) ?>"
                      data-descripcion="<?= htmlspecialchars($producto['descripcion']) ?>"
                      data-precio="<?= $producto['precio'] ?>">
                <?= htmlspecialchars($producto['nombre']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-3">
          <input type="number" name="cantidades[]" class="form-control cantidad" placeholder="Cantidad" min="1" required>
        </div>
        <div class="col-md-3">
          <input type="text" class="form-control subtotal" readonly placeholder="Subtotal">
        </div>
        <div class="col-md-2 d-grid">
          <button type="button" class="btn btn-danger eliminar-producto">🗑️</button>
        </div>
        <div class="col-md-12 mt-1 descripcion-producto small fst-italic text-light"></div>
      </div>
    </div>

    <button type="button" class="btn btn-secondary mb-3" id="agregar-producto">➕ Agregar otro producto</button>

    <h4 class="text-end text-light">Total: <span id="totalVenta" class="badge bg-success fs-5">S/ 0.00</span></h4>

    <div class="d-flex justify-content-between mt-3">
      <a href="index.php" class="btn btn-outline-light">⬅ Cancelar</a>
      <button type="submit" class="btn btn-success">💾 Registrar Venta</button>
    </div>
  </form>
</div>

<script>
document.getElementById('agregar-producto').addEventListener('click', () => {
  const container = document.getElementById('productos-container');
  const clone = container.querySelector('.producto-item').cloneNode(true);

  clone.querySelector('.producto-select').value = '';
  clone.querySelector('.cantidad').value = '';
  clone.querySelector('.subtotal').value = '';
  clone.querySelector('.descripcion-producto').textContent = '';

  container.appendChild(clone);
});

document.addEventListener('input', actualizarTotales);
document.addEventListener('change', actualizarTotales);

document.addEventListener('click', e => {
  if (e.target.classList.contains('eliminar-producto')) {
    const items = document.querySelectorAll('.producto-item');
    if (items.length > 1) {
      e.target.closest('.producto-item').remove();
      actualizarTotales();
    }
  }
});

function actualizarTotales() {
  let total = 0;
  document.querySelectorAll('.producto-item').forEach(item => {
    const select = item.querySelector('.producto-select');
    const cantidad = parseFloat(item.querySelector('.cantidad').value) || 0;
    const precio = parseFloat(select.selectedOptions[0]?.getAttribute('data-precio')) || 0;

    const subtotal = cantidad * precio;
    item.querySelector('.subtotal').value = subtotal.toFixed(2);
    item.querySelector('.descripcion-producto').textContent = select.selectedOptions[0]?.getAttribute('data-descripcion') || '';
    total += subtotal;
  });

  document.getElementById('totalVenta').textContent = 'S/ ' + total.toFixed(2);
}
</script>

</body>
</html>
