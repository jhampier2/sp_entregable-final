<?php
include 'conexion.php'; // archivo con conexión PDO

try {
    $stmt = $pdo->query("CALL sp_listar_ventas()");
    $ventas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();

    echo json_encode($ventas);

} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
