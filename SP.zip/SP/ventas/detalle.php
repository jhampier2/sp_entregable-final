<?php
include 'conexion.php';

$id_venta = $_GET['id_venta'] ?? null;

if (!$id_venta) {
    die("ID de venta no especificado.");
}

// Obtener datos de la venta
$stmtVenta = $pdo->prepare("CALL sp_obtener_venta(:id_venta)");
$stmtVenta->bindParam(':id_venta', $id_venta, PDO::PARAM_INT);
$stmtVenta->execute();
$venta = $stmtVenta->fetch(PDO::FETCH_ASSOC);
$stmtVenta->closeCursor();

// Obtener detalles de la venta
$stmtDetalles = $pdo->prepare("CALL sp_obtener_detalle_venta(:id_venta)");
$stmtDetalles->bindParam(':id_venta', $id_venta, PDO::PARAM_INT);
$stmtDetalles->execute();
$detalles = $stmtDetalles->fetchAll(PDO::FETCH_ASSOC);
$stmtDetalles->closeCursor();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalle de Venta</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h2 class="text-primary">Detalle de Venta #<?= htmlspecialchars($id_venta) ?></h2>

    <div class="mb-4">
        <strong>Cliente:</strong> <?= htmlspecialchars($venta['nombres']) ?><br>
        <strong>Fecha:</strong> <?= htmlspecialchars($venta['fecha']) ?>
    </div>

    <h4 class="mb-3">Productos Vendidos:</h4>
    <table class="table table-bordered table-hover bg-white">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Precio</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $total = 0;
            foreach ($detalles as $i => $item):
                $subtotal = $item['precio'] * $item['cantidad'];
                $total += $subtotal;
            ?>
            <tr>
                <td><?= $i + 1 ?></td>
                <td><?= htmlspecialchars($item['nombre']) ?></td>
                <td><?= $item['cantidad'] ?></td>
                <td>S/ <?= number_format($item['precio'], 2) ?></td>
                <td>S/ <?= number_format($subtotal, 2) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot class="table-light">
            <tr>
                <th colspan="4" class="text-end">Total:</th>
                <th>S/ <?= number_format($total, 2) ?></th>
            </tr>
        </tfoot>
    </table>
    <a href="reporte_pdf.php?id_venta=<?= $id_venta ?>" target="_blank" class="btn btn-danger mt-3">
    📄 Descargar Reporte PDF
    </a>

    <a href="index.php" class="btn btn-secondary">⬅ Volver</a>
</div>

</body>
</html>
