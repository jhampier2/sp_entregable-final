<?php
require('fpdf/fpdf.php');  // Ajusta la ruta según dónde pongas fpdf
include 'conexion.php';

$id_venta = $_GET['id_venta'] ?? null;
if (!$id_venta) {
    die("ID de venta no especificado.");
}

// Obtener datos de la venta
$stmtVenta = $pdo->prepare("CALL sp_obtener_venta(:id_venta)");
$stmtVenta->bindParam(':id_venta', $id_venta, PDO::PARAM_INT);
$stmtVenta->execute();
$venta = $stmtVenta->fetch(PDO::FETCH_ASSOC);
$stmtVenta->closeCursor();

// Obtener detalles de la venta
$stmtDetalles = $pdo->prepare("CALL sp_obtener_detalle_venta(:id_venta)");
$stmtDetalles->bindParam(':id_venta', $id_venta, PDO::PARAM_INT);
$stmtDetalles->execute();
$detalles = $stmtDetalles->fetchAll(PDO::FETCH_ASSOC);
$stmtDetalles->closeCursor();

class PDF extends FPDF {
    function Header() {
        $this->SetFont('Arial','B',14);
        $this->Cell(0,10,'Reporte de Venta',0,1,'C');
        $this->Ln(5);
    }
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial','I',8);
        $this->Cell(0,10,'Pagina '.$this->PageNo().'/{nb}',0,0,'C');
    }
}

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();

$pdf->SetFont('Arial','',12);
$pdf->Cell(0,10,"Venta ID: {$venta['id_venta']}",0,1);
$pdf->Cell(0,10,"Fecha: {$venta['fecha']}",0,1);
$pdf->Cell(0,10,"Cliente: {$venta['nombres']}",0,1);
$pdf->Ln(10);

// Tabla de productos
$pdf->SetFont('Arial','B',12);
$pdf->Cell(10,10,'#',1);
$pdf->Cell(90,10,'Producto',1);
$pdf->Cell(25,10,'Cantidad',1,0,'C');
$pdf->Cell(30,10,'Precio',1,0,'R');
$pdf->Cell(35,10,'Subtotal',1,1,'R');

$pdf->SetFont('Arial','',12);
$total = 0;
foreach ($detalles as $i => $item) {
    $subtotal = $item['precio'] * $item['cantidad'];
    $total += $subtotal;
    $pdf->Cell(10,10,$i+1,1);
    $pdf->Cell(90,10,$item['nombre'],1);
    $pdf->Cell(25,10,$item['cantidad'],1,0,'C');
    $pdf->Cell(30,10,number_format($item['precio'], 2),1,0,'R');
    $pdf->Cell(35,10,number_format($subtotal, 2),1,1,'R');
}

$pdf->SetFont('Arial','B',12);
$pdf->Cell(155,10,'Total',1);
$pdf->Cell(35,10,number_format($total, 2),1,1,'R');

$pdf->Output('I', "venta_{$id_venta}.pdf");  // Mostrar en el navegador
