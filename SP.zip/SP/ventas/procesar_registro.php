<?php
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_cliente = $_POST["id_cliente"];
    $fecha = $_POST["fecha"];
    $productos = $_POST["productos"];
    $cantidades = $_POST["cantidades"];

    try {
        $pdo->beginTransaction();

        // 1. Calcular total antes de insertar la venta
        $total = 0;
        for ($i = 0; $i < count($productos); $i++) {
            $id_producto = $productos[$i];
            $cantidad = $cantidades[$i];

            // Obtener precio del producto mediante SP
            $stmtPrecio = $pdo->prepare("CALL sp_obtener_precio_producto(:id_producto)");
            $stmtPrecio->bindParam(":id_producto", $id_producto);
            $stmtPrecio->execute();
            $fila = $stmtPrecio->fetch(PDO::FETCH_ASSOC);
            $precio = $fila['precio'];
            $stmtPrecio->closeCursor();

            $subtotal = $precio * $cantidad;
            $total += $subtotal;
        }

        // 2. Insertar venta con total calculado y obtener ID generado
        $stmtVenta = $pdo->prepare("CALL sp_insertar_venta(:fecha, :id_cliente, :total)");
        $stmtVenta->bindParam(":fecha", $fecha);
        $stmtVenta->bindParam(":id_cliente", $id_cliente);
        $stmtVenta->bindParam(":total", $total);
        $stmtVenta->execute();

        $resultado = $stmtVenta->fetch(PDO::FETCH_ASSOC);
        $id_venta = $resultado["id_venta_nueva"];
        $stmtVenta->closeCursor();

        // 3. Insertar detalles de la venta
        $stmtDetalle = $pdo->prepare("CALL sp_insertar_detalle_venta(:id_venta, :id_producto, :cantidad)");

        for ($i = 0; $i < count($productos); $i++) {
            $id_producto = $productos[$i];
            $cantidad = $cantidades[$i];

            $stmtDetalle->bindParam(":id_venta", $id_venta);
            $stmtDetalle->bindParam(":id_producto", $id_producto);
            $stmtDetalle->bindParam(":cantidad", $cantidad);
            $stmtDetalle->execute();
            $stmtDetalle->closeCursor();
        }

        $pdo->commit();

        echo "<script>alert('Venta registrada con éxito. Total: S/ " . number_format($total, 2) . "'); window.location='index.php';</script>";
    } catch (Exception $e) {
        $pdo->rollBack();
        die("Error al registrar venta: " . $e->getMessage());
    }
}
?>
